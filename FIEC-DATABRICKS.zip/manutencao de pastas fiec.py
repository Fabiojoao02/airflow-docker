# Databricks notebook source
# DBTITLE 1,Criar diretorio
#%fs mkdirs /FileStore/tables/fiec/delta/
%fs mkdirs /FileStore/tables/fiec/carga_antaq/


# COMMAND ----------

# MAGIC %fs help

# COMMAND ----------

# DBTITLE 1,Mover arquivos da pasta X para pasta Y
source_directory = "/FileStore/tables/fiec/"
destination_directory = "/FileStore/tables/fiec/2023/"

# Lista os arquivos no diretório de origem com a extensão .txt
txt_files = dbutils.fs.ls(source_directory)
txt_files = [file_info for file_info in txt_files if file_info.name.endswith(".txt")]

for file_info in txt_files:
    source_path = file_info.path
    destination_path = destination_directory + file_info.name
    dbutils.fs.mv(source_path, destination_path)

# COMMAND ----------

# DBTITLE 1,Lista arquivos da pasta
# MAGIC %fs ls  /FileStore/tables/fiec/

# COMMAND ----------

# MAGIC %fs ls /FileStore/tables/fiec/deltaCarga_Conteinerizada.delta
# MAGIC
# MAGIC

# COMMAND ----------

# DBTITLE 1,Excluir pasta e arquivos das pastas

# Caminho do diretório que você deseja esvaziar
#diretorio_a_esvaziar = "dbfs:/FileStore/tables/fiec/delta"
diretorio_a_esvaziar = "dbfs:/FileStore/tables/fiec/delta/Atracacao.delta"

# Obtenha a lista de arquivos no diretório
arquivos = dbutils.fs.ls(diretorio_a_esvaziar)

# Exclua cada arquivo no diretório
for arquivo in arquivos:
    dbutils.fs.rm(arquivo.path, recurse=True)

# Agora você pode excluir o diretório vazio
dbutils.fs.rm(diretorio_a_esvaziar)


# COMMAND ----------

from pyspark.sql.functions import lit,current_timestamp

from pyspark.sql.types import StructType, StructField, DoubleType, StringType, IntegerType


timestamp_df = spark.range(1).select(current_timestamp().alias("timestamp"))

# Extrai o valor do timestamp como string
data_update = timestamp_df.first().timestamp.strftime('%Y-%m-%d %H:%M:%S')

#df = spark.read.format("csv").option("header", "true").option("delimiter", ";").option("inferSchema", "true").option("encoding", "UTF-8").load("dbfs:/FileStore/tables/fiec/2021/2021Atracacao.txt")
#df_Atracacao = spark.read.format("parquet").load("dbfs:/FileStore/tables/fiec/2021/2021Atracacao.txt")
nome_arquivo1='dbfs:/FileStore/tables/fiec/2021/2021Atracacao.txt'
nome_arquivo1='dbfs:/FileStore/tables/fiec/2022/2022Atracacao.txt'
nome_arquivo1='dbfs:/FileStore/tables/fiec/2023/2023Atracacao.txt'
caminho_completo = 'dbfs:/FileStore/tables/fiec/delta/Atracacao.delta'
print("2-Existe arquivos ")
df = spark.read.format("csv").option("header", "true").option("delimiter", ";").option("inferSchema", "true").option("encoding", "UTF-8").load(nome_arquivo1)
# Carregar dados existentes, se já houver um arquivo Parquet
#try:
 #   print(f"3-Existe dados dados {caminho_completo}")
  #  dados_existente = spark.read.format("parquet").load(caminho_completo)
    #spark.read.parquet(caminho_completo)
    # Combinar dados existentes com os novos dados
    #df = df.union(dados_existente)
#except:
 #   print("4-Não existe dados")
# Escrever os dados completos no arquivo Parquet
#df.write.format("parquet").mode("append").save(caminho_completo)

# Adiciona a nova coluna com o tipo timestamp
df_with_new_column = df.withColumn("data_update", lit(data_update))    

# Salva o DataFrame com a nova coluna em um novo arquivo Parquet
df_with_new_column.write.parquet(caminho_completo, mode="append")


#df_Atracacao = spark.read.format("parquet").load("dbfs:/FileStore/tables/fiec/delta/Atracacao.delta")


# COMMAND ----------

df_Atracacao = spark.read.format("parquet").load("dbfs:/FileStore/tables/fiec/delta/Atracacao.delta")

# Definir o esquema com a coluna "Nº da Capitania" como DoubleType
schema = StructType([
    StructField("Nº da Capitania", IntegerType(), True),  # O "True" permite valores nulos
    # ... Definir outras colunas do esquema ...
])
df_Atracacao = spark.read.schema(schema).parquet("dbfs:/FileStore/tables/fiec/delta/Atracacao.delta/")