# Databricks notebook source

#dbutils.widgets.removeAll()

# COMMAND ----------

#import datetime

# Obtém a data atual no formato YYYYMM (ano e mês)
#if not pAnomes:
 #   data_atual = pAnomes
#else:    
 #   data_atual = datetime.datetime.now().strftime("%Y%m")
#pAnomes = '202301'
#print(pAnomes)
# Cria o widget interativo com o valor padrão sendo a data atual
#dbutils.widgets.text("pAnomes",  "Insira o valor de pAnomes:")

# COMMAND ----------

# DBTITLE 1,Converte o parametro mes numerico em str 01=jan...


def anomes_extenso(ano, mes):

    # Dicionário de correspondência entre o número do mês e o nome do mês
    meses = {
        'jan': '01', 'fev': '02', 'mar': '03', 'abr': '04',
        'mai': '05', 'jun': '06', 'jul': '07', 'ago': '08',
        'set': '09', 'out': '10', 'nov': '11', 'dez': '12'
    }

    # Verifica se o mês está no dicionário, se não, mantém o valor original
    mes_extenso = meses.get(mes, mes)

    # Cria o resultado combinando o ano e o mês
    anomes_extenso = ano + mes_extenso

    # Exibe o resultado
    print("Resultado:", anomes_extenso)  
    return anomes_extenso
    # Registra a variável no contexto SQL usando PySpark SQL
    #spark.sql("SET anomes_extenso=" + anomes_extenso)


# COMMAND ----------

# DBTITLE 1,Criando dataframe dos objetos

#df_Atracacao = dbfs:/FileStore/tables/fiec/delta/Atracacao.delta"
df_Atracacao = spark.read.format("delta").load("dbfs:/FileStore/tables/fiec/delta/Atracacao.delta")
df_Atracacao.createOrReplaceTempView("Atracacao")


#df_Carga_Conteinerizada = dbfs:/FileStore/tables/fiec/delta/Carga_Conteinerizada.delta
df_Carga_Conteinerizada = spark.read.format("parquet").load("dbfs:/FileStore/tables/fiec/delta/Carga_Conteinerizada.delta")
df_Carga_Conteinerizada.createOrReplaceTempView("Carga_Conteinerizada")

#df_Carga_Hidrovia = dbfs:/FileStore/tables/fiec/delta/Carga_Hidrovia.delta
df_Carga_Hidrovia = spark.read.format("parquet").load("dbfs:/FileStore/tables/fiec/delta/Carga_Hidrovia.delta")
df_Carga_Hidrovia.createOrReplaceTempView("Carga_Hidrovia ")

#df_Carga_Regiao = dbfs:/FileStore/tables/fiec/delta/Carga_Regiao.delta
df_Carga_Regiao = spark.read.format("parquet").load("dbfs:/FileStore/tables/fiec/delta/Carga_Regiao.delta")
df_Carga_Regiao.createOrReplaceTempView("Carga_Regiao")

#df_Carga_Rio = dbfs:/FileStore/tables/fiec/delta/Carga_Rio.delta
df_Carga_Rio = spark.read.format("parquet").load("dbfs:/FileStore/tables/fiec/delta/Carga_Rio.delta")
df_Carga_Rio.createOrReplaceTempView("Carga_Rio")

#df_Carga = dbfs:/FileStore/tables/fiec/delta/Carga.delta
df_Carga = spark.read.format("parquet").load("dbfs:/FileStore/tables/fiec/delta/Carga.delta")
df_Carga.createOrReplaceTempView("Carga")

#df_TaxaOcupacao = dbfs:/FileStore/tables/fiec/delta/TaxaOcupacao.delta
df_TaxaOcupacao = spark.read.format("parquet").load("dbfs:/FileStore/tables/fiec/delta/TaxaOcupacao.delta")
df_TaxaOcupacao.createOrReplaceTempView("TaxaOcupacao")

#df_TemposAtracacao = dbfs:/FileStore/tables/fiec/delta/TemposAtracacao.delta
df_TemposAtracacao = spark.read.format("parquet").load("dbfs:/FileStore/tables/fiec/delta/TemposAtracacao.delta")
df_TemposAtracacao.createOrReplaceTempView("TemposAtracacao")

#df_TemposAtracacaoParalisacao = dbfs:/FileStore/tables/fiec/delta/TemposAtracacaoParalisacao.delta
df_TemposAtracacaoParalisacao = spark.read.format("parquet").load("dbfs:/FileStore/tables/fiec/delta/TemposAtracacaoParalisacao.delta")
df_TemposAtracacaoParalisacao.createOrReplaceTempView("TemposAtracacaoParalisacao")


# COMMAND ----------

from pyspark.sql.types import StructType, StructField, DoubleType, StringType, IntegerType, FloatType, BinaryType

# Definir o esquema com a coluna "Nº da Capitania" como DoubleType
schema = StructType([

StructField("IDAtracacao", IntegerType(), nullable=True),
StructField("CDTUP", StringType(), nullable=True),
StructField("IDBerco", StringType(), nullable=True),
StructField("Berço", StringType(), nullable=True),
StructField("Porto Atracação", StringType(), nullable=True),
StructField("Apelido Instalação Portuária", StringType(), nullable=True),
StructField("Complexo Portuário", StringType(), nullable=True),
StructField("Tipo da Autoridade Portuária", StringType(), nullable=True),
StructField("Data Atracação", StringType(), nullable=True),
StructField("Data Chegada", StringType(), nullable=True),
StructField("Data Desatracação", StringType(), nullable=True),
StructField("Data Início Operação", StringType(), nullable=True),
StructField("Data Término Operação", StringType(), nullable=True),
StructField("Ano", IntegerType(), nullable=True),
StructField("Mes", StringType(), nullable=True),
StructField("Tipo de Operação", StringType(), nullable=True),
StructField("Tipo de Navegação da Atracação", StringType(), nullable=True),
StructField("Nacionalidade do Armador", IntegerType(), nullable=True),
StructField("FlagMCOperacaoAtracacao", IntegerType(), nullable=True),
StructField("Terminal", StringType(), nullable=True),
StructField("Município", StringType(), nullable=True),
StructField("UF", StringType(), nullable=True),
StructField("SGUF", StringType(), nullable=True),
StructField("Região Geográfica", StringType(), nullable=True),
StructField("Nº da Capitania", BinaryType(), nullable=True),
StructField("Nº do IMO", IntegerType(), nullable=True),
StructField("data_update", StringType(), nullable=True),
])
df_Atracacao = spark.read.format("parquet").schema(schema).load("dbfs:/FileStore/tables/fiec/delta/Atracacao.delta/")
df_Atracacao.createOrReplaceTempView("Atracacao")



# COMMAND ----------

from pyspark.sql.types import StructType, StructField, DoubleType, StringType, IntegerType, FloatType, BinaryType
from pyspark.sql.functions import col
df_Atracacao = spark.read.format("parquet").schema(schema).load("dbfs:/FileStore/tables/fiec/delta/Atracacao.delta/")

df_Atracacao = df_Atracacao.withColumn("Nr Capitania",col("Nº da Capitania").cast(StringType()))
df_Atracacao =  df_Atracacao.drop(col("Nº da Capitania"))

df_Atracacao.createOrReplaceTempView("Atracacao")


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from Atracacao limit 10

# COMMAND ----------

#df_Atracacao.display()
df_Atracacao.show()

# COMMAND ----------

# DBTITLE 1,Criação do objeto Atracação
# MAGIC %sql
# MAGIC delete from fiec.atracacao_fato; --where concat(ano_inicio_operacao,mes_inicio_operacao)  = anomes_extenso;
# MAGIC insert into fiec.atracacao_fato
# MAGIC (
# MAGIC idatracacao 						
# MAGIC ,cdtup 										
# MAGIC ,idberco 								
# MAGIC ,berco 										
# MAGIC ,porto_atracacao 	
# MAGIC ,apelido 
# MAGIC ,complexo
# MAGIC ,tipo_da_autoridade_portuaria
# MAGIC ,data_atracacao
# MAGIC ,data_chegada
# MAGIC ,data_desatracacao
# MAGIC ,data_inicio_operacao
# MAGIC ,data_termino_operacao
# MAGIC ,ano_inicio_operacao
# MAGIC ,mes_inicio_operacao
# MAGIC ,mes_inicio_operacao_int
# MAGIC ,tipo_operacao 
# MAGIC ,tipo_navegacao_atracacao
# MAGIC ,nacionalidade_armador
# MAGIC ,flagmcoperacaoatracacao
# MAGIC ,terminal 					
# MAGIC ,atracacao_municipio
# MAGIC ,instalacao_portuaria_uf
# MAGIC ,portuario_sguf 			
# MAGIC ,regiao_geografica 		
# MAGIC ,nr_capitania 				
# MAGIC ,nr_imo 					
# MAGIC
# MAGIC ,tesperaatracacao 	
# MAGIC ,tesperainicioop 		
# MAGIC ,toperacao 				  
# MAGIC ,tesperadesatracacao
# MAGIC ,tatracado 				  
# MAGIC ,testadia 				  
# MAGIC ,data_update
# MAGIC )
# MAGIC select
# MAGIC   atr.IDAtracacao as idatracacao,
# MAGIC   atr.CDTUP as cdtup,
# MAGIC   atr.IDBerco as idberco,
# MAGIC   atr.`Berço` as berco,
# MAGIC   atr.`Porto Atracação` as porto_atracacao,
# MAGIC   atr.`Apelido Instalação Portuária` as apelido,
# MAGIC   atr.`Complexo Portuário` as complexo,
# MAGIC   atr.`Tipo da Autoridade Portuária` as tipo_da_autoridade_portuaria,
# MAGIC   to_timestamp(atr.`Data Atracação`) as data_atracacao,
# MAGIC   to_timestamp(atr.`Data Chegada`) as data_chegada,
# MAGIC   to_timestamp(atr.`Data Desatracação`) as data_desatracacao,
# MAGIC   to_timestamp(atr.`Data Início Operação`) as data_inicio_operacao,
# MAGIC   to_timestamp(atr.`Data Término Operação`) as data_termino_operacao,
# MAGIC   atr.Ano as ano_inicio_operacao,
# MAGIC   atr.Mes as mes_inicio_operacao,
# MAGIC   case when atr.Mes = 'jan' then '01' 
# MAGIC       when atr.Mes = 'fev' then '02' 
# MAGIC       when atr.Mes = 'mar' then '03' 
# MAGIC       when atr.Mes = 'abr' then '04' 
# MAGIC       when atr.Mes = 'mai' then '05' 
# MAGIC       when atr.Mes = 'jun' then '06' 
# MAGIC       when atr.Mes = 'jul' then '07' 
# MAGIC       when atr.Mes = 'ago' then '08' 
# MAGIC       when atr.Mes = 'set' then '09' 
# MAGIC       when atr.Mes = 'out' then '10' 
# MAGIC       when atr.Mes = 'nov' then '11' 
# MAGIC       when atr.Mes = 'dez' then '12' 
# MAGIC   end mes_inicio_operacao_int,  
# MAGIC   atr.`Tipo de Operação` as tipo_operacao,
# MAGIC   atr.`Tipo de Navegação da Atracação` as tipo_navegacao_atracacao,
# MAGIC   atr.`Nacionalidade do Armador` as nacionalidade_armador,
# MAGIC   atr.`FlagMCOperacaoAtracacao` as flagmcoperacaoatracacao,
# MAGIC   atr.Terminal as terminal,
# MAGIC   atr.`Município` as atracacao_municipio,
# MAGIC   atr.UF as instalacao_portuaria_uf,
# MAGIC   atr.SGUF as portuario_sguf,
# MAGIC   atr.`Região Geográfica` as regiao_geografica, 
# MAGIC   'atr.`Nr Capitania`'				as nr_capitania,
# MAGIC   atr.`Nº do IMO` as nr_imo,
# MAGIC   cast(replace(tpatr.TEsperaDesatracacao,',','.') as float) as tesperaatracacao,
# MAGIC   cast(replace(tpatr.TEsperaAtracacao,',','.') as float) as tEsperaAtracacao,
# MAGIC   cast(replace(tpatr.TEsperaInicioOp,',','.') as float) as tEsperaInicioOp,
# MAGIC   cast(replace(tpatr.TOperacao,',','.') as float) as tOperacao,
# MAGIC   cast(replace(tpatr.TAtracado,',','.') as float) as tAtracado,
# MAGIC   cast(replace(tpatr.TEstadia,',','.') as float) as tEstadia,
# MAGIC   atr.data_update
# MAGIC from
# MAGIC   Atracacao atr
# MAGIC   join TemposAtracacao tpatr on 
# MAGIC   tpatr.IDAtracacao = atr.IDAtracacao
# MAGIC --where concat(Ano,mes)  = anomes_extenso  
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) qde , ano_inicio_operacao from fiec.atracacao_fato
# MAGIC group by ano_inicio_operacao

# COMMAND ----------

# DBTITLE 1,Criação do objeto Carga
# MAGIC %sql
# MAGIC delete from fiec.carga_fato; --where concat(ano_inicio_operacao_atracacao,mes_inicio_operacao_atracacao) = anomes_extenso ;
# MAGIC insert into fiec.carga_fato
# MAGIC (
# MAGIC idcarga
# MAGIC ,idatracacao
# MAGIC ,origem_percurso
# MAGIC ,destino
# MAGIC ,cdmercadoria
# MAGIC ,tipo_operacao_carga
# MAGIC ,carga_geral_acondicionamento
# MAGIC ,conteinerestado
# MAGIC ,tipo_navegacao
# MAGIC ,flagautorizacao
# MAGIC ,flagcabotagem
# MAGIC ,Flagcabotagemmovimentacao
# MAGIC ,flagconteinertamanho
# MAGIC ,flagtransporteviainterioir
# MAGIC ,percurso_transporte_em_vias_interiores
# MAGIC ,transporte_interiores
# MAGIC ,stnaturezacarga
# MAGIC ,STSH2
# MAGIC ,STSH4
# MAGIC ,natureza_carga
# MAGIC ,sentido
# MAGIC ,teu
# MAGIC ,qtcarga
# MAGIC ,vlpesocargabruta
# MAGIC ,ano_inicio_operacao_atracacao 
# MAGIC ,mes_inicio_operacao_atracacao 
# MAGIC ,mes_inicio_operacao_atracacao_int 
# MAGIC ,data_update
# MAGIC )
# MAGIC select
# MAGIC IDCarga								                  as idcarga
# MAGIC ,cg.IDAtracacao						              as idatracacao
# MAGIC ,cg.Origem								              as origem_percurso
# MAGIC ,cg.Destino							                as destino
# MAGIC ,cg.CDMercadoria						            as cdmercadoria
# MAGIC ,cg.`Tipo Operação da Carga`				    as tipo_operacao_carga
# MAGIC ,cg.`Carga Geral Acondicionamento`		  as carga_geral_acondicionamento
# MAGIC ,cg.ConteinerEstado					            as conteinerestado
# MAGIC ,cg.`Tipo Navegação`						        as tipo_navegacao
# MAGIC ,cg.FlagAutorizacao					            as flagautorizacao
# MAGIC ,cg.FlagCabotagem						            as flagcabotagem
# MAGIC ,cg.FlagCabotagemMovimentacao		        as Flagcabotagemmovimentacao
# MAGIC ,cg.flagconteinertamanho				        as flagconteinertamanho
# MAGIC ,cg.FlagTransporteViaInterioir	        as flagtransporteviainterioir
# MAGIC ,cg.`Percurso Transporte em vias Interiores` as percurso_transporte_em_vias_interiores
# MAGIC ,cg.`Percurso Transporte Interiores`		as transporte_interiores
# MAGIC ,cg.STNaturezaCarga						          as stnaturezacarga
# MAGIC ,cg.STSH2									              as STSH2
# MAGIC ,cg.STSH4									              as STSH4
# MAGIC ,cg.`Natureza da Carga`						      as natureza_carga
# MAGIC ,cg.Sentido								              as sentido
# MAGIC ,cg.TEU									                as teu
# MAGIC ,cast(replace(cg.QTCarga, ',','.') as float)					  as qtcarga
# MAGIC ,cast(replace(cg.VLPesoCargaBruta, ',','.') as float)  as vlpesocargabruta
# MAGIC ,fat.ano_inicio_operacao                 as ano_inicio_operacao_atracacao 
# MAGIC ,fat.mes_inicio_operacao                 as mes_inicio_operacao_atracacao 
# MAGIC ,case when mes_inicio_operacao_atracacao = 'jan' then '01' 
# MAGIC       when mes_inicio_operacao_atracacao = 'fev' then '02' 
# MAGIC       when mes_inicio_operacao_atracacao = 'mar' then '03' 
# MAGIC       when mes_inicio_operacao_atracacao = 'abr' then '04' 
# MAGIC       when mes_inicio_operacao_atracacao = 'mai' then '05' 
# MAGIC       when mes_inicio_operacao_atracacao = 'jun' then '06' 
# MAGIC       when mes_inicio_operacao_atracacao = 'jul' then '07' 
# MAGIC       when mes_inicio_operacao_atracacao = 'ago' then '08' 
# MAGIC       when mes_inicio_operacao_atracacao = 'set' then '09' 
# MAGIC       when mes_inicio_operacao_atracacao = 'out' then '10' 
# MAGIC       when mes_inicio_operacao_atracacao = 'nov' then '11' 
# MAGIC       when mes_inicio_operacao_atracacao = 'dez' then '12' 
# MAGIC end mes_inicio_operacao_atracacao_int 
# MAGIC ,cg.data_update
# MAGIC from
# MAGIC   carga cg
# MAGIC   join fiec.atracacao_fato fat on 
# MAGIC   fat.IDAtracacao = cg.IDAtracacao
# MAGIC
# MAGIC  

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from fiec.atracacao_fato limit 1

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from fiec.carga_fato limit 1

# COMMAND ----------

# MAGIC %sql
# MAGIC select 
# MAGIC count(distinct at.idatracacao) nr_atracacao
# MAGIC ,avg(at.tatracado) `tempo medio atracado`
# MAGIC ,avg(at.tesperaatracacao) `Tempo medio espera atracado`
# MAGIC ,at.atracacao_municipio Localidade
# MAGIC ,ano_inicio_operacao,mes_inicio_operacao_int
# MAGIC from fiec.atracacao_fato at
# MAGIC group by at.atracacao_municipio,ano_inicio_operacao,mes_inicio_operacao_int
# MAGIC order by ano_inicio_operacao, mes_inicio_operacao_int, nr_atracacao desc
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC WITH AtracacoesPorMes AS (
# MAGIC     SELECT
# MAGIC         atracacao_municipio AS Localidade,
# MAGIC         ano_inicio_operacao,
# MAGIC         mes_inicio_operacao_int,
# MAGIC         COUNT(DISTINCT idatracacao) AS nr_atracacao,
# MAGIC         AVG(tatracado) AS tempo_medio_atracado,
# MAGIC         AVG(tesperaatracacao) AS tempo_medio_espera_atracado
# MAGIC     FROM fiec.atracacao_fato
# MAGIC     GROUP BY atracacao_municipio, ano_inicio_operacao, mes_inicio_operacao_int
# MAGIC )
# MAGIC
# MAGIC SELECT
# MAGIC     AtracacoesPorMes.Localidade,
# MAGIC     AtracacoesPorMes.ano_inicio_operacao,
# MAGIC     AtracacoesPorMes.mes_inicio_operacao_int,
# MAGIC     AtracacoesPorMes.nr_atracacao,
# MAGIC     AtracacoesPorMes.tempo_medio_atracado,
# MAGIC     AtracacoesPorMes.tempo_medio_espera_atracado,
# MAGIC     AtracacoesPorMes.nr_atracacao - COALESCE(LAG(AtracacoesPorMes.nr_atracacao) OVER (
# MAGIC         PARTITION BY AtracacoesPorMes.Localidade
# MAGIC         ORDER BY AtracacoesPorMes.ano_inicio_operacao, AtracacoesPorMes.mes_inicio_operacao_int
# MAGIC     ), 0) AS variacao_numero_atracacoes
# MAGIC FROM AtracacoesPorMes
# MAGIC where AtracacoesPorMes.Localidade = 'Vitória' and mes_inicio_operacao_int='02'
# MAGIC ORDER BY AtracacoesPorMes.ano_inicio_operacao, AtracacoesPorMes.mes_inicio_operacao_int, AtracacoesPorMes.nr_atracacao DESC;

# COMMAND ----------

# MAGIC %sql
# MAGIC select 
# MAGIC count(distinct at.idatracacao) nr_atracacao
# MAGIC ,avg(at.tatracado) `tempo medio atracado`
# MAGIC ,avg(at.tesperaatracacao) `Tempo medio espera atracado`
# MAGIC ,at.atracacao_municipio Localidade
# MAGIC ,ano_inicio_operacao,mes_inicio_operacao
# MAGIC from fiec.atracacao_fato at
# MAGIC where 1=1 --and at.atracacao_municipio  ='Niterói' 
# MAGIC and ano_inicio_operacao = 2022  --and  mes_inicio_operacao = 'fev'
# MAGIC group by at.atracacao_municipio,ano_inicio_operacao,mes_inicio_operacao
# MAGIC order by ano_inicio_operacao, mes_inicio_operacao, nr_atracacao desc

# COMMAND ----------

