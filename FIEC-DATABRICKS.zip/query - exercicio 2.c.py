# Databricks notebook source
# MAGIC %sql
# MAGIC WITH AtracacoesPorMes AS (
# MAGIC     SELECT
# MAGIC         atracacao_municipio AS Localidade,
# MAGIC         ano_inicio_operacao,
# MAGIC         mes_inicio_operacao_int,
# MAGIC         COUNT(DISTINCT idatracacao) AS nr_atracacao,
# MAGIC         AVG(tatracado) AS tempo_medio_atracado,
# MAGIC         AVG(tesperaatracacao) AS tempo_medio_espera_atracado
# MAGIC     FROM fiec.atracacao_fato
# MAGIC     GROUP BY atracacao_municipio, ano_inicio_operacao, mes_inicio_operacao_int
# MAGIC )
# MAGIC
# MAGIC SELECT
# MAGIC     AtracacoesPorMes.Localidade,
# MAGIC     AtracacoesPorMes.ano_inicio_operacao,
# MAGIC     AtracacoesPorMes.mes_inicio_operacao_int,
# MAGIC     AtracacoesPorMes.nr_atracacao,
# MAGIC     AtracacoesPorMes.tempo_medio_atracado,
# MAGIC     AtracacoesPorMes.tempo_medio_espera_atracado,
# MAGIC     AtracacoesPorMes.nr_atracacao - COALESCE(LAG(AtracacoesPorMes.nr_atracacao) OVER (
# MAGIC         PARTITION BY AtracacoesPorMes.Localidade
# MAGIC         ORDER BY AtracacoesPorMes.ano_inicio_operacao, AtracacoesPorMes.mes_inicio_operacao_int
# MAGIC     ), 0) AS variacao_numero_atracacoes
# MAGIC FROM AtracacoesPorMes
# MAGIC --where AtracacoesPorMes.Localidade = 'Vitória' and mes_inicio_operacao_int='02'
# MAGIC ORDER BY AtracacoesPorMes.ano_inicio_operacao, AtracacoesPorMes.mes_inicio_operacao_int, AtracacoesPorMes.nr_atracacao DESC;

# COMMAND ----------

