# Databricks notebook source

# Caminho do diretório que você deseja esvaziar
diretorio_a_esvaziar = "dbfs:/user/hive/warehouse/fiec.db/carga_fato"

# Obtenha a lista de arquivos no diretório
arquivos = dbutils.fs.ls(diretorio_a_esvaziar)

# Exclua cada arquivo no diretório
for arquivo in arquivos:
    dbutils.fs.rm(arquivo.path, recurse=True)

# Agora você pode excluir o diretório vazio
dbutils.fs.rm(diretorio_a_esvaziar)

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS  fiec.carga_fato

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS fiec.carga_fato
# MAGIC --create table fiec.carga_fato
# MAGIC (
# MAGIC idcarga string 							
# MAGIC ,idatracacao string 						
# MAGIC ,origem_percurso string 					
# MAGIC ,destino string 							
# MAGIC ,cdmercadoria string 
# MAGIC ,tipo_operacao_carga string 				
# MAGIC ,carga_geral_acondicionamento string 		
# MAGIC ,conteinerestado string 					
# MAGIC ,tipo_navegacao string 						
# MAGIC ,flagautorizacao string 					
# MAGIC ,flagcabotagem string 						
# MAGIC ,flagcabotagemmovimentacao string 			
# MAGIC ,flagconteinertamanho string 
# MAGIC ,flagtransporteviainterioir string
# MAGIC ,percurso_transporte_em_vias_interiores string
# MAGIC ,transporte_interiores string
# MAGIC ,stnaturezacarga string
# MAGIC ,stsh2 string
# MAGIC ,stsh4 string
# MAGIC ,natureza_carga string
# MAGIC ,sentido string
# MAGIC ,teu string
# MAGIC ,qtcarga float
# MAGIC ,vlpesocargabruta float
# MAGIC ,ano_inicio_operacao_atracacao string
# MAGIC ,mes_inicio_operacao_atracacao string
# MAGIC ,data_update timestamp
# MAGIC ,mes_inicio_operacao_atracacao_int string
# MAGIC )
# MAGIC

# COMMAND ----------

