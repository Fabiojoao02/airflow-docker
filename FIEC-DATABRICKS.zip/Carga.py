# Databricks notebook source
# MAGIC %sql
# MAGIC create database fiec;
# MAGIC use fiec;
# MAGIC --show database
# MAGIC

# COMMAND ----------

# MAGIC %fs mkdirs /FileStore/tables/fiec/2023/

# COMMAND ----------


dbutils.fs.rm('/FileStore/tables/fiec/delta/atracacao.delta', recurse=True)


# COMMAND ----------

from datetime import datetime,timedelta
from pyspark.sql.functions import lit,current_timestamp
from delta.tables import *
import sys

# Obtém o valor único de current_timestamp() como um DataFrame
timestamp_df = spark.range(1).select(current_timestamp().alias("timestamp"))

# Extrai o valor do timestamp como string
data_update = timestamp_df.first().timestamp.strftime('%Y-%m-%d %H:%M:%S')

ano_atual = datetime.today().year
ano_anterior = ano_atual - 2


#ateant = dia_anterior.date()
#yearant = dateant.strftime("%Y")
#date = currentDateTime.date()
#year = date.strftime("%Y")
i = int(ano_anterior)
a = int(ano_atual)
#print(i,a)
#i=2021
#a=2021
#pasta = "/FileStore/tables/fiec/"
#subpasta = str(i)
#completo = pasta+subpasta
while i <= a:
    pasta = "/FileStore/tables/fiec/"
    subpasta = str(i)
    completo = pasta+subpasta
   # try:
        # Verifique se a pasta existe no DBFS
    if dbutils.fs.ls(completo):
        print("1-A pasta existe no DBFS.")
        file_paths = [f.path for f in dbutils.fs.ls(completo) if f.isFile() and f.name.endswith(".txt")]
        print(file_paths)
        # Extrair o nome entre o último "/" e ".txt"

        # Itere sobre os caminhos de arquivo
        for caminho_arquivo in file_paths:
            nome_arquivo1 = caminho_arquivo
            nome_arquivo = caminho_arquivo.split("/")[-1].split(".")[0]
            nome_arquivo_sem_prefixo = nome_arquivo.replace(str(i), '')
            # Definir o sufixo .delta
            nome_delta = nome_arquivo_sem_prefixo + ".delta"
            caminho_arquivo_delta = "dbfs:/FileStore/tables/fiec/delta/"
            caminho_completo = caminho_arquivo_delta+nome_delta
            print(nome_arquivo1)
            print(caminho_completo)
            if caminho_completo:
                print("2-Existe arquivos ")
                df = spark.read.format("csv").option("header", "true").option("delimiter", ";").option("inferSchema", "true").option("encoding", "UTF-8").load(nome_arquivo1)
                # Carregar dados existentes, se já houver um arquivo Parquet
                #try:
                #    print(f"3-Existe dados daos {caminho_completo}")
                #    dados_existente = spark.read.format("parquet").load(caminho_completo)
                #    #spark.read.parquet(caminho_completo)
                #    # Combinar dados existentes com os novos dados
                #    df = df.union(dados_existente)
                #except:
                #    print("4-Não existe dados")
                ## Escrever os dados completos no arquivo Parquet
                #df.write.format("parquet").mode("append").save(caminho_completo)

                # Adiciona a nova coluna com o tipo timestamp
                df_with_new_column = df.withColumn("data_update", lit(data_update))    

                # Salva o DataFrame com a nova coluna em um novo arquivo Parquet
                df_with_new_column.write.parquet(caminho_completo, mode="append")


            else:
                print("5-Não Existe arquivos ")
                df = spark.read.format("csv").option("header", "true").option("delimiter", ";").option("inferSchema", "true").option("encoding", "UTF-8").load(nome_arquivo1)
                df.write.format("parquet").save(caminho_completo)


    else:
        print("6-A pasta não existe no DBFS. Indo para a próxima pasta.")

        

  #  except FileNotFoundException:
   #     print("A pasta não existe no DBFS. Indo para a próxima pasta.")

    i +=  1

    #data_atual = datetime.datetime.now()
#atracacao = spark.read.csv("/FileStore/tables/fiec/2021Atracacao.txt", header=True, inferSchema=True, sep=";")
#display()

# COMMAND ----------

df_Atracacao = spark.read.format("parquet").load("dbfs:/FileStore/tables/fiec/delta/Atracacao.delta")

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, DoubleType, StringType, IntegerType

# Definir o esquema com a coluna "Nº da Capitania" como DoubleType
schema = StructType([
    StructField("Nº da Capitania", IntegerType(), True),  # O "True" permite valores nulos
    # ... Definir outras colunas do esquema ...
])
df = spark.read.schema(schema).parquet("dbfs:/FileStore/tables/fiec/delta/Atracacao.delta/")

# COMMAND ----------

df_Atracacao = spark.read.format("parquet").load("dbfs:/FileStore/tables/fiec/delta/Atracacao.delta")
df_Atracacao.createOrReplaceTempView("Atracacao")
#display()
df_Atracacao.show()

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*), substring(`Data Atracação`,7,4) ano from Atracacao
# MAGIC group by substring(`Data Atracação`,7,4) 
# MAGIC

# COMMAND ----------

