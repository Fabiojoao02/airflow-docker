# Databricks notebook source
# DBTITLE 1,Drop tabela atracacao_fato

# Caminho do diretório que você deseja esvaziar
diretorio_a_esvaziar = "dbfs:/user/hive/warehouse/fiec.db/atracacao_fato"

# Obtenha a lista de arquivos no diretório
arquivos = dbutils.fs.ls(diretorio_a_esvaziar)

# Exclua cada arquivo no diretório
for arquivo in arquivos:
    dbutils.fs.rm(arquivo.path, recurse=True)

# Agora você pode excluir o diretório vazio
dbutils.fs.rm(diretorio_a_esvaziar)

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS fiec.atracacao_fato

# COMMAND ----------

# MAGIC %sql
# MAGIC --ALTER TABLE your_table_name
# MAGIC ---SET TBLPROPERTIES ('delta.columnMapping' = 'name');
# MAGIC --IF EXISTS  
# MAGIC CREATE TABLE IF NOT EXISTS fiec.atracacao_fato
# MAGIC (
# MAGIC idatracacao 		string						
# MAGIC ,cdtup 				string 								
# MAGIC ,idberco 			string 							
# MAGIC ,berco 				string 								
# MAGIC ,porto_atracacao 	string 								
# MAGIC ,apelido 			string 							
# MAGIC ,complexo 			string 							
# MAGIC ,tipo_da_autoridade_portuaria string 		
# MAGIC ,data_atracacao 		TIMESTAMP						
# MAGIC ,data_chegada 			TIMESTAMP 						
# MAGIC ,data_desatracacao 		TIMESTAMP 					
# MAGIC ,data_inicio_operacao 	TIMESTAMP 				
# MAGIC ,data_termino_operacao 	TIMESTAMP 				
# MAGIC ,ano_inicio_operacao 	string 	
# MAGIC ,mes_inicio_operacao 	string 	
# MAGIC ,tipo_operacao 			string 					
# MAGIC ,tipo_navegacao_atracacao string
# MAGIC ,nacionalidade_armador  	int
# MAGIC ,flagmcoperacaoatracacao 	int
# MAGIC ,terminal 					string
# MAGIC ,atracacao_municipio 		string
# MAGIC ,instalacao_portuaria_uf 	string
# MAGIC ,portuario_sguf 			string	
# MAGIC ,regiao_geografica 			string
# MAGIC ,nr_capitania 				string
# MAGIC ,nr_imo 					string
# MAGIC
# MAGIC ,tesperaatracacao 		float
# MAGIC ,tesperainicioop 		float
# MAGIC ,toperacao 				float
# MAGIC ,tesperadesatracacao 	float
# MAGIC ,tatracado 				float
# MAGIC ,testadia 				float
# MAGIC ,data_update timestamp
# MAGIC , mes_inicio_operacao_int string
# MAGIC )

# COMMAND ----------

