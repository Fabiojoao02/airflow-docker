# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE database IF NOT EXISTS fiec;
# MAGIC use fiec;
# MAGIC --show database

# COMMAND ----------

